## ---- include = FALSE----------------------------------------------------
library(crudr)
run <- FALSE
root_dir <- paste(rep("../", 1), collapse = "")
knitr::opts_chunk$set(comment = "#>", collapse = TRUE)
knitr::opts_knit$set(root.dir = root_dir)

