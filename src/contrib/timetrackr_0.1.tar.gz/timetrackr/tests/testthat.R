library(testthat)
library(timetrackr)

test_check("timetrackr")
